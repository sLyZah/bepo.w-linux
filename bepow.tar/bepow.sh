#!/bin/bash
sudo mv Downloads/evdev.xml /usr/share/X11/xkb/rules/evdev.xml
sudo mv Downloads/fr /usr/share/X11/xkb/symbols/fr
echo "Select the correct keyboard language >> French (Bepo, Intl, Flamme Sly)"
echo ":)"
